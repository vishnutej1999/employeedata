const express = require("express");
const router = express.Router();

const { createEmployee } = require("../controllers/employeeController");
const {getEmployees}=require("../controllers/employeeController");
const {singleEmployee}=require("../controllers/employeeController");
const {updateEmployee}=require("../controllers/employeeController");
const {deleteEmployee}=require("../controllers/employeeController");

router.post("/add-emp", createEmployee);
router.get("/addemployees",getEmployees);
router.get("/employee/:id",singleEmployee);
router.put("/update/:id",updateEmployee);
router.delete("/delete/:id",deleteEmployee);
module.exports = router;
